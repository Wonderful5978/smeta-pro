@echo off
REM Открыть в браузере по умолчанию (без режима app)
cd /d "%~dp0"
start "" "%cd%\index.html"

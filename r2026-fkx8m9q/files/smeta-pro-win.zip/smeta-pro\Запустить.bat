@echo off
REM ================================================================
REM  Смета-Про — запуск в режиме приложения
REM  Ищет Chrome / Edge через PowerShell (работает в любой локали)
REM ================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "APP=%cd%\index.html"
set "URL=file:///%APP:\=/%"

REM --- Ищем Chrome через PowerShell ---
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "$p = (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)'; if (-not $p) { $p = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue).'(default)' }; if ($p -and (Test-Path $p)) { Write-Output $p }"`) do set "CHROME=%%i"

REM --- Если в реестре нет — пробуем стандартные пути ---
if not defined CHROME (
    if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
)
if not defined CHROME (
    if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
)
if not defined CHROME (
    if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

if defined CHROME (
    start "" "!CHROME!" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Иначе ищем Edge ---
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "$p = (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction SilentlyContinue).'(default)'; if (-not $p) { $p = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction SilentlyContinue).'(default)' }; if ($p -and (Test-Path $p)) { Write-Output $p }"`) do set "EDGE=%%i"

if not defined EDGE (
    if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
)
if not defined EDGE (
    if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
)

if defined EDGE (
    start "" "!EDGE!" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Не нашли ничего — выдаём подсказку ---
echo.
echo ============================================================
echo  Не найден Chrome или Microsoft Edge.
echo.
echo  Рекомендуется использовать онлайн-версию:
echo    https://smeta-pro.pages.dev/r2026-fkx8m9q/
echo.
echo  Там можно установить как приложение через "Установить"
echo  в адресной строке. Данные будут сохраняться надёжно.
echo ============================================================
echo.
pause

start "" "%URL%"

endlocal

@echo off
REM ================================================================
REM  Смета-Про — запуск в режиме приложения
REM  Ищет Chrome / Edge через реестр Windows (App Paths)
REM  и через стандартные пути установки
REM ================================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "APP=%cd%\index.html"
set "URL=file:///%APP:\=/%"

REM --- 1. Ищем Chrome через App Paths в реестре (HKLM) ---
for /f "tokens=2*" %%a in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" /ve 2^>nul') do set "CHROME=%%b"
REM --- 2. Если не нашли — пробуем HKCU (для user install) ---
if not defined CHROME (
    for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" /ve 2^>nul') do set "CHROME=%%b"
)
REM --- 3. Если до сих пор не нашли — пробуем стандартные пути ---
if not defined CHROME (
    if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
)
if not defined CHROME (
    if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
)
if not defined CHROME (
    if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

REM --- Если Chrome нашли — запускаем ---
if defined CHROME (
    echo Запуск через Chrome: !CHROME!
    start "" "!CHROME!" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Иначе пробуем Edge (он есть на Windows 10/11 по умолчанию) ---
set "EDGE="
for /f "tokens=2*" %%a in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" /ve 2^>nul') do set "EDGE=%%b"
if not defined EDGE (
    for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" /ve 2^>nul') do set "EDGE=%%b"
)
if not defined EDGE (
    if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
)
if not defined EDGE (
    if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
)

if defined EDGE (
    echo Запуск через Edge: !EDGE!
    start "" "!EDGE!" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Ничего не нашли ---
echo.
echo ============================================================
echo  Не найден Chrome или Microsoft Edge.
echo.
echo  Чтобы программа работала корректно:
echo    - Установите Chrome (https://www.google.com/chrome/)
echo    - Или Microsoft Edge (https://www.microsoft.com/edge)
echo.
echo  Альтернатива: открой файл index.html вручную в любом
echo  современном браузере (двойной клик по index.html).
echo ============================================================
echo.
pause

REM Открываем в браузере по умолчанию как последний вариант
start "" "%URL%"

endlocal

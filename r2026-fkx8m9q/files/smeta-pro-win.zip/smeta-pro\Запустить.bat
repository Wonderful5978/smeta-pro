@echo off
REM ================================================================
REM  Смета-Про — запуск в режиме приложения
REM  Ищет Chrome / Edge и открывает index.html в "приложении"
REM  (без адресной строки, в своём окне)
REM ================================================================

setlocal
cd /d "%~dp0"
set "APP=%cd%\index.html"
set "URL=file:///%APP:\=/%"

REM --- Пробуем Chrome (стандартные пути) ---
set "CHROME1=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "CHROME2=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "CHROME3=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if exist "%CHROME1%" (
    start "" "%CHROME1%" --app="%URL%" --window-size=1280,860
    goto :eof
)
if exist "%CHROME2%" (
    start "" "%CHROME2%" --app="%URL%" --window-size=1280,860
    goto :eof
)
if exist "%CHROME3%" (
    start "" "%CHROME3%" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Пробуем Edge ---
set "EDGE1=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "EDGE2=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE1%" (
    start "" "%EDGE1%" --app="%URL%" --window-size=1280,860
    goto :eof
)
if exist "%EDGE2%" (
    start "" "%EDGE2%" --app="%URL%" --window-size=1280,860
    goto :eof
)

REM --- Если ничего не нашли — открываем в браузере по умолчанию ---
echo Chrome или Edge не найден. Открываю в браузере по умолчанию...
start "" "%URL%"

endlocal
